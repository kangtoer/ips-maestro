import React, { useState, useEffect, useRef } from 'react';
import { 
  BookOpen, 
  FileText, 
  PlusCircle, 
  Share2, 
  Download, 
  Settings, 
  LogOut, 
  Search,
  CheckCircle,
  AlertCircle,
  Globe,
  HardDrive,
  Layout,
  GraduationCap,
  Sparkles,
  Loader2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import { generateTeachingContent, generateBlogContent } from './lib/gemini';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { Document, Packer, Paragraph, TextRun } from 'docx';
import confetti from 'canvas-confetti';

// --- Types ---
type Tab = 'beranda' | 'rpp' | 'materi' | 'blog' | 'drive';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('beranda');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [topic, setTopic] = useState('');
  const [aiResult, setAiResult] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [status, setStatus] = useState<{ type: 'success' | 'error' | null, message: string }>({ type: null, message: '' });
  
  const contentRef = useRef<HTMLDivElement>(null);

  // --- Auth Check ---
  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const res = await fetch('/api/auth/status');
      const data = await res.json();
      setIsAuthenticated(data.authenticated);
    } catch (err) {
      console.error('Auth check fail', err);
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async () => {
    try {
      const res = await fetch('/api/auth/url');
      const { url } = await res.json();
      const width = 600, height = 700;
      const left = window.screenX + (window.innerWidth - width) / 2;
      const top = window.screenY + (window.innerHeight - height) / 2;
      
      const authWindow = window.open(url, 'google_oauth', `width=${width},height=${height},left=${left},top=${top}`);
      
      const handleMessage = (event: MessageEvent) => {
        // Handle postMessage from popup
        if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
          setIsAuthenticated(true);
          confetti();
        }
      };
      window.addEventListener('message', handleMessage);
    } catch (err) {
      console.error(err);
    }
  };

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    setIsAuthenticated(false);
  };

  // --- Actions ---
  const generateRPP = async () => {
    if (!topic) return;
    setIsGenerating(true);
    setAiResult('');
    try {
      const res = await generateTeachingContent('RPP Lengkap Kurikulum Merdeka', topic);
      setAiResult(res || '');
      setActiveTab('materi'); // Show result
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePostToBlog = async (title: string, content: string) => {
    setStatus({ type: null, message: '' });
    try {
      const res = await fetch('/api/blogger/post', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, content, blogUrl: 'catatanguruips.blogspot.com' }),
      });
      const data = await res.json();
      if (res.ok) {
        setStatus({ type: 'success', message: 'Berhasil diposting ke Blogger!' });
        confetti();
      } else {
        setStatus({ type: 'error', message: data.error || 'Gagal posting' });
      }
    } catch (err) {
      setStatus({ type: 'error', message: 'Kesalahan jaringan' });
    }
  };

  const exportPDF = async () => {
    if (!contentRef.current) return;
    const canvas = await html2canvas(contentRef.current);
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(`IPS_${topic || 'Document'}.pdf`);
  };

  const exportWord = () => {
    const doc = new Document({
      sections: [{
        properties: {},
        children: [
          new Paragraph({
            children: [
              new TextRun({
                text: aiResult || "Dokumen Kosong",
                bold: false,
              }),
            ],
          }),
        ],
      }],
    });

    Packer.toBlob(doc).then(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `IPS_${topic || 'Document'}.docx`;
      a.click();
    });
  };

  // --- Sub-Components ---
  const Sidebar = () => {
    const items: { id: Tab, icon: any, label: string }[] = [
      { id: 'beranda', icon: Layout, label: 'Dashboard' },
      { id: 'rpp', icon: FileText, label: 'Modul RPP / MA' },
      { id: 'materi', icon: BookOpen, label: 'Bank Materi' },
      { id: 'blog', icon: Globe, label: 'Kelola Blog' },
      { id: 'drive', icon: HardDrive, label: 'Drive Cloud' },
    ];

    return (
      <aside className="w-full md:w-[260px] bg-white border-b md:border-b-0 md:border-r-2 border-slate-200 flex flex-col p-6 h-auto md:h-screen sticky top-0">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white font-bold text-lg">
            IPS
          </div>
          <div className="font-bold text-lg text-text-dark">Maestro</div>
        </div>

        <nav className="flex flex-row md:flex-col gap-2 overflow-x-auto md:overflow-x-visible pb-2 md:pb-0">
          {items.map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all whitespace-nowrap md:whitespace-normal ${
                activeTab === item.id 
                  ? 'bg-primary-light text-primary' 
                  : 'text-text-light hover:bg-slate-50'
              }`}
            >
              <item.icon className={`w-5 h-5 ${activeTab === item.id ? 'text-primary' : 'text-text-light'}`} />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="mt-auto pt-6 border-t border-slate-100 hidden md:block">
          <div className="flex items-center gap-3 text-xs text-text-light">
            <div className="w-2 h-2 rounded-full bg-success"></div>
            <span>Drive Sync: Aktif</span>
          </div>
          
          <div className="mt-4">
            {isAuthenticated ? (
              <button 
                onClick={handleLogout}
                className="flex items-center gap-2 text-rose-600 font-bold text-xs hover:text-rose-700 transition-colors"
              >
                <LogOut className="w-4 h-4" /> Keluar Akun
              </button>
            ) : (
              <button 
                onClick={handleLogin}
                className="w-full bg-primary text-white py-3 rounded-xl font-bold text-xs hover:bg-indigo-700 transition-all shadow-sm"
              >
                Connect Google
              </button>
            )}
          </div>
        </div>
      </aside>
    );
  };

  const Footer = () => (
    <footer className="mt-8 border-t border-slate-100 pt-6">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="text-[11px] text-text-light bg-slate-100 px-3 py-2 rounded-lg border border-slate-200 text-center md:text-left">
          <strong>Dibuat oleh:</strong><br />
          Catur Pamungkas, S.Pd.,Gr.<br />
          <a href="https://catatanguruips.blogspot.com" target="_blank" className="hover:text-primary">catatanguruips.blogspot.com</a>
        </div>
        <div className="flex items-center gap-2 text-indigo-600 bg-indigo-50 px-4 py-2 rounded-full border border-indigo-100">
          <CheckCircle className="w-4 h-4" />
          <span className="text-[12px] font-bold">Verified Educator Assistant</span>
        </div>
      </div>
    </footer>
  );

  if (loading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Bekerja untuk Guru...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-bg-theme font-sans text-text-dark">
      <Sidebar />
      
      <main className="flex-1 p-6 md:p-10 flex flex-col min-h-screen overflow-y-auto">
        <header className="flex flex-col md:flex-row justify-between items-start gap-4 mb-10">
          <div className="welcome">
            <h2 className="text-3xl font-bold text-text-dark mb-1">Halo, Pak Catur! 👋</h2>
            <p className="text-text-light">Siap untuk menginspirasi siswa hari ini? Kelola semua kebutuhan IPS Anda di satu tempat.</p>
          </div>
          
          <div className="flex gap-2">
            {!isAuthenticated && (
              <button 
                onClick={handleLogin}
                className="md:hidden flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-lg text-sm font-bold shadow-sm"
              >
                Connect Google
              </button>
            )}
          </div>
        </header>
        
        <div className="flex-1">
          <AnimatePresence mode="wait">
            {activeTab === 'beranda' && (
              <motion.div 
                key="beranda"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="grid md:grid-cols-3 gap-6"
              >
                {/* Card 1: RPP Wizard */}
                <div className="bg-white rounded-[24px] p-8 shadow-sm border border-slate-50 flex flex-col group hover:shadow-md transition-all">
                  <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center text-xl mb-6 group-hover:scale-110 transition-transform">
                    📝
                  </div>
                  <h3 className="text-xl font-bold mb-3">Modul RPP / MA</h3>
                  <p className="text-sm text-text-light leading-relaxed flex-1">
                    Buat Modul Ajar interaktif berbasis Kurikulum Merdeka secara instan dengan bantuan AI.
                  </p>
                  <button 
                    onClick={() => setActiveTab('rpp')}
                    className="mt-6 bg-secondary text-text-dark py-3 rounded-xl font-bold text-sm hover:opacity-90 transition-all text-center"
                  >
                    Mulai Buat Modul
                  </button>
                </div>

                {/* Card 2: Materials */}
                <div className="bg-white rounded-[24px] p-8 shadow-sm border border-slate-50 flex flex-col group hover:shadow-md transition-all">
                  <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center text-xl mb-6 group-hover:scale-110 transition-transform">
                    🌍
                  </div>
                  <h3 className="text-xl font-bold mb-3">Bank Materi</h3>
                  <p className="text-sm text-text-light leading-relaxed flex-1">
                    Kumpulan materi sejarah, geografi dan ekonomi terpadu untuk pembelajaran di kelas.
                  </p>
                  <button 
                    onClick={() => setActiveTab('materi')}
                    className="mt-6 bg-primary text-white py-3 rounded-xl font-bold text-sm hover:opacity-90 transition-all text-center"
                  >
                    Buka Galeri
                  </button>
                </div>

                {/* Card 3: Assessment */}
                <div className="bg-white rounded-[24px] p-8 shadow-sm border border-slate-50 flex flex-col group hover:shadow-md transition-all">
                  <div className="w-12 h-12 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center text-xl mb-6 group-hover:scale-110 transition-transform">
                    📊
                  </div>
                  <h3 className="text-xl font-bold mb-3">Penilaian</h3>
                  <p className="text-sm text-text-light leading-relaxed flex-1">
                    Input nilai formatif dan sumatif secara sistematis. Export otomatis ke Drive Database.
                  </p>
                  <button className="mt-6 bg-primary text-white py-3 rounded-xl font-bold text-sm hover:opacity-90 transition-all text-center">
                    Input Nilai
                  </button>
                </div>

                {/* Card 4: Blog (Spans 2) */}
                <div className="md:col-span-2 blog-gradient rounded-[24px] p-8 text-white flex flex-col shadow-lg">
                  <div className="flex justify-between items-center mb-6">
                    <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center text-xl">
                      🌐
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-widest bg-white/20 px-3 py-1 rounded-full">Publish to Blogspot</span>
                  </div>
                  <h3 className="text-2xl font-bold mb-3">Catatan Guru IPS Portal</h3>
                  <p className="text-sm text-white/90 leading-relaxed mb-6">
                    Tulis artikel materi hari ini dan langsung posting ke <strong>catatanguruips.blogspot.com</strong>.
                    Setiap postingan otomatis memiliki tombol unduh file pendukung.
                  </p>
                  <div className="flex flex-wrap gap-2 mb-8">
                    {['PDF Export', 'Word Export', 'Auto-Backup Drive'].map(pill => (
                      <span key={pill} className="px-3 py-1 bg-white/20 rounded-full text-[10px] font-bold uppercase tracking-wider">{pill}</span>
                    ))}
                  </div>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <button 
                      onClick={() => setActiveTab('blog')}
                      className="flex-1 bg-white text-primary py-3 rounded-xl font-bold text-sm hover:bg-slate-50 transition-all shadow-sm"
                    >
                      Tulis Postingan Baru
                    </button>
                    <button className="flex-1 border border-white/50 text-white py-3 rounded-xl font-bold text-sm hover:bg-white/10 transition-all">
                      Lihat Statistik Blog
                    </button>
                  </div>
                </div>

                {/* Card 5: Drive */}
                <div className="bg-white rounded-[24px] p-8 shadow-sm border border-slate-50 flex flex-col group hover:shadow-md transition-all">
                  <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center text-xl mb-6 group-hover:scale-110 transition-transform">
                    📁
                  </div>
                  <h3 className="text-xl font-bold mb-3">Drive Cloud</h3>
                  <p className="text-sm text-text-light leading-relaxed flex-1">
                    Akses database file ajar di Google Drive. Sinkronisasi otomatis antar perangkat.
                  </p>
                  <button 
                    onClick={() => setActiveTab('drive')}
                    className="mt-6 bg-success text-white py-3 rounded-xl font-bold text-sm hover:opacity-90 transition-all text-center"
                  >
                    Buka Drive
                  </button>
                </div>
              </motion.div>
            )}

            {activeTab === 'rpp' && (
              <motion.div 
                key="rpp"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="max-w-4xl mx-auto space-y-8"
              >
                <div className="bg-white p-10 rounded-[32px] shadow-sm border border-slate-100">
                  <div className="text-center mb-10">
                    <div className="w-16 h-16 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center mx-auto mb-4 text-3xl">✨</div>
                    <h2 className="text-2xl font-bold text-text-dark mb-2">Penyihir Konten IPS</h2>
                    <p className="text-text-light">AI akan menyusun modul ajar lengkap khusus untuk Pak Catur.</p>
                  </div>

                  <div className="relative group">
                    <input 
                      type="text" 
                      value={topic}
                      onChange={(e) => setTopic(e.target.value)}
                      placeholder="Contoh: Interaksi Antarruang di ASEAN, Masa Praaksara..."
                      className="w-full p-6 pr-40 bg-slate-50 border-2 border-slate-100 rounded-2xl text-lg font-medium focus:border-primary focus:bg-white transition-all outline-none"
                      onKeyDown={(e) => e.key === 'Enter' && generateRPP()}
                    />
                    <button 
                      onClick={generateRPP}
                      disabled={isGenerating || !topic}
                      className="absolute right-3 top-3 bottom-3 px-8 bg-primary text-white rounded-xl font-bold hover:bg-indigo-700 disabled:opacity-50 flex items-center gap-2 shadow-lg"
                    >
                      {isGenerating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
                      Generate
                    </button>
                  </div>

                  <div className="flex flex-wrap gap-2 mt-6 justify-center">
                    {['ASEAN', 'Peta & Skala', 'Globalisasi', 'Ekspor Impor', 'Majapahit'].map(t => (
                      <button 
                        key={t}
                        onClick={() => setTopic(t)}
                        className="px-5 py-2 bg-white border border-slate-200 rounded-full text-sm font-semibold text-text-light hover:border-primary hover:text-primary transition-all"
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>

                {isGenerating && (
                  <div className="bg-primary/5 p-8 rounded-3xl flex items-center gap-6 border border-primary/10 animate-pulse">
                    <div className="bg-primary p-3 rounded-xl">
                      <Loader2 className="w-6 h-6 text-white animate-spin" />
                    </div>
                    <div>
                      <p className="text-primary font-bold">Proses Berlangsung...</p>
                      <p className="text-primary/70 text-sm italic">AI sedang menyusun diksi pedagogis terbaik untuk Pak Catur.</p>
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'materi' && (
              <motion.div 
                key="materi"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="h-full flex flex-col gap-6"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-6">
                  <div>
                    <h2 className="text-2xl font-bold">Modul Preview</h2>
                    <p className="text-sm text-text-light">Topik: <span className="text-primary font-bold uppercase">{topic || 'No Topic'}</span></p>
                  </div>
                  
                  <div className="flex gap-2">
                    <button onClick={exportPDF} className="flex items-center gap-2 px-5 py-3 bg-rose-600 text-white rounded-xl text-sm font-bold hover:bg-rose-700 transition-all shadow-sm">
                      <Download className="w-4 h-4" /> PDF
                    </button>
                    <button onClick={exportWord} className="flex items-center gap-2 px-5 py-3 bg-primary text-white rounded-xl text-sm font-bold hover:bg-indigo-700 transition-all shadow-sm">
                      <FileText className="w-4 h-4" /> Word
                    </button>
                    <button 
                      onClick={() => handlePostToBlog(`Materi IPS: ${topic}`, aiResult)}
                      className="flex items-center gap-2 px-5 py-3 bg-secondary text-text-dark rounded-xl text-sm font-bold hover:opacity-90 transition-all shadow-sm"
                    >
                      <Share2 className="w-4 h-4" /> Share to Blog
                    </button>
                  </div>
                </div>

                <div className="flex-1 bg-slate-50/50 rounded-[32px] p-4 md:p-8 overflow-y-auto border border-slate-100 flex justify-center">
                  <div ref={contentRef} className="max-w-4xl w-full prose prose-indigo bg-white p-8 md:p-16 shadow-xl rounded-2xl min-h-full">
                    {aiResult ? (
                      <div className="markdown-body">
                        <ReactMarkdown>{aiResult}</ReactMarkdown>
                      </div>
                    ) : (
                      <div className="h-full flex flex-col items-center justify-center py-24 text-slate-300">
                        <div className="bg-slate-50 p-6 rounded-full mb-6">
                          <FileText className="w-20 h-20 opacity-40" />
                        </div>
                        <p className="text-xl font-bold">Belum Ada Konten</p>
                        <p className="text-sm max-w-xs text-center mt-2">Mulai dengan membuat materi di tab 'Modul RPP' untuk melihat hasilnya di sini.</p>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'blog' && (
              <motion.div 
                key="blog"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="max-w-4xl mx-auto space-y-8"
              >
                <div className="flex items-center gap-4 bg-primary-light border border-primary/20 p-6 rounded-2xl text-primary">
                  <Globe className="w-6 h-6 flex-shrink-0" />
                  <div>
                    <p className="font-bold text-sm">Target Integrasi: catatanguruips.blogspot.com</p>
                    <p className="text-xs opacity-80 mt-1">Status: Terhubung dengan Akun Google Bapak.</p>
                  </div>
                </div>

                {status.type && (
                  <div className={`p-4 rounded-xl flex items-center gap-3 ${status.type === 'success' ? 'bg-success/10 text-success border-success/20' : 'bg-red-50 text-red-600 border-red-100'} border`}>
                    {status.type === 'success' ? <CheckCircle className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
                    <p className="font-bold">{status.message}</p>
                  </div>
                )}

                <div className="bg-white border border-slate-100 rounded-[32px] overflow-hidden shadow-md">
                  <div className="p-8 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
                    <h3 className="font-bold text-xl">Draft Postingan Blog</h3>
                    <div className="flex gap-2">
                       <span className="w-3 h-3 rounded-full bg-red-400"></span>
                       <span className="w-3 h-3 rounded-full bg-amber-400"></span>
                       <span className="w-3 h-3 rounded-full bg-success"></span>
                    </div>
                  </div>
                  <div className="p-8 space-y-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-text-light uppercase tracking-widest pl-1">Judul Artikel</label>
                      <input 
                        type="text" 
                        defaultValue={`Materi IPS: ${topic || 'Update Terbaru'}`}
                        className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-primary font-bold text-lg"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-text-light uppercase tracking-widest pl-1">Konten HTML/Markdown</label>
                      <textarea 
                        className="w-full h-[400px] p-6 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-primary font-mono text-sm leading-relaxed"
                        defaultValue={aiResult ? `<!-- Konten Otomatis IPS Maestro -->\n${aiResult}` : ''}
                      ></textarea>
                    </div>
                    
                    <div className="flex flex-col sm:flex-row justify-between items-center pt-6 gap-4">
                      <div className="flex items-center gap-3">
                         <div className="flex -space-x-2">
                            {[1,2,3].map(i => <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-slate-200" />)}
                         </div>
                         <p className="text-[11px] text-text-light font-medium italic">Diposting sebagai Catur Pamungkas</p>
                      </div>
                      
                      <button 
                        onClick={() => handlePostToBlog(`Update Terbaru Pak Catur: ${topic}`, aiResult)}
                        className="w-full sm:w-auto bg-primary text-white px-10 py-4 rounded-xl font-bold hover:bg-indigo-700 transition-all flex items-center justify-center gap-2 shadow-lg hover:translate-y-[-2px]"
                      >
                        <Globe className="w-5 h-5" />
                        Terbitkan Konten
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'drive' && (
              <motion.div 
                key="drive"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="h-full flex flex-col items-center justify-center p-6 text-center"
              >
                <div className="bg-emerald-50 w-32 h-32 rounded-[40px] flex items-center justify-center mb-8 rotate-12 group hover:rotate-0 transition-transform duration-500 shadow-sm border border-emerald-100">
                  <HardDrive className="w-16 h-16 text-emerald-600" />
                </div>
                <h2 className="text-3xl font-bold text-text-dark mb-3">Sync dengan Google Drive</h2>
                <p className="text-text-light max-w-sm mb-10 leading-relaxed text-lg">Setiap dokumen yang Bapak buat akan tersimpan rapi di folder <span className="text-emerald-600 font-bold">"IPS Maestro"</span> secara otomatis.</p>
                
                <div className="flex flex-col sm:flex-row gap-4 w-full max-w-sm">
                  <button 
                    disabled={!aiResult || !isAuthenticated}
                    onClick={() => {
                      fetch('/api/drive/upload', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ name: `IPS_${topic}.txt`, content: aiResult, mimeType: 'text/plain' })
                      }).then(() => {
                        confetti();
                        setStatus({ type: 'success', message: 'Berhasil diupload ke Drive!' });
                      });
                    }}
                    className="flex-1 bg-success text-white px-8 py-4 rounded-2xl font-bold hover:opacity-90 transition-all disabled:opacity-50 shadow-lg shadow-emerald-200"
                  >
                    Simpan Materi Ini
                  </button>
                  <button className="flex-1 border-2 border-emerald-100 text-emerald-600 px-8 py-4 rounded-2xl font-bold hover:bg-emerald-50 transition-all">
                    Lihat Folder Drive
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <Footer />
      </main>
    </div>
  );
}
