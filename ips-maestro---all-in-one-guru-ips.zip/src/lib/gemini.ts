import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

export const generateTeachingContent = async (type: string, topic: string) => {
  const model = "gemini-3-flash-preview";
  const prompt = `Anda adalah asisten ahli untuk guru IPS SMP di Indonesia. 
  Buatlah ${type} untuk materi: ${topic}.
  Output harus dalam format Markdown yang rapi dan profesional.
  Sertakan bagian: 
  - Tujuan Pembelajaran
  - Materi Inti
  - Aktivitas Siswa
  - Soal Latihan (5 pilihan ganda + kunci jawaban)
  - Penutup
  
  Gunakan bahasa Indonesia yang sesuai dengan kurikulum merdeka.
  Atribusi: Dibuat oleh Catur Pamungkas, S.Pd.,Gr. (catatanguruips.blogspot.com)`;

  const response = await ai.models.generateContent({
    model: model,
    contents: prompt,
    config: {
      temperature: 0.7,
    }
  });

  return response.text;
};

export const generateBlogContent = async (topic: string) => {
  const model = "gemini-3-flash-preview";
  const prompt = `Buatlah draf postingan blog pendidikan yang menarik untuk materi IPS SMP: ${topic}.
  Postingan ini ditujukan untuk audiens guru dan siswa.
  Gunakan gaya bahasa yang edukatif namun santai.
  Output harus dalam format HTML agar mudah diupload ke Blogger.
  Sertakan judul yang SEO friendly di bagian atas sebagai [JUDUL: ...].
  Tambahkan penutup: "Ditulis oleh Catur Pamungkas, S.Pd.,Gr. di catatanguruips.blogspot.com"`;

  const response = await ai.models.generateContent({
    model: model,
    contents: prompt,
    config: {
      temperature: 0.8,
    }
  });

  return response.text;
};
